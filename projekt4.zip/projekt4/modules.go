package main

type TableRow struct {
	Header string
	Value  string
}
